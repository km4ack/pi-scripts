import badger2040
badger = badger2040.Badger2040()

myname = "Jason"
call = "KM4ACK"
title = "Build-A-Pi"
#set to 1 for Pi logo or 2 for YT QR Code
image_num = 2

if image_num==1:
    myimage = "pi_logo.bin"
else:
    myimage = "qr_code.bin"

def callbox():
   #draw rectangle
   badger.pen(0)	#set color to black
   badger.rectangle(0, 0, 300, 40)
   #draw callsign
   badger.font("sans")
   badger.pen(15)	#set color to white
   badger.thickness(3)
   badger.text(call, 40, 20, scale=1.8)

def namebox():
   #draw name
   badger.font("sans")
   badger.pen(0)
   badger.thickness(4)
   badger.text(myname, 35, 65, scale=1.5)

def titlebox():
   #draw line
   badger.line(0, 90, 200, 90)
   #draw title
   badger.font("serif")
   badger.thickness(2)
   badger.text(title, 35, 110, scale=.75)

badger.clear()
badger.invert("true")
#Draw image background
my_image = bytearray(int(296 * 128 / 8))
open(myimage, "r").readinto(my_image)
badger.image(my_image)

callbox()
namebox()
titlebox()

badger.update()