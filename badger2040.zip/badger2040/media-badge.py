import badger2040
badger = badger2040.Badger2040()

myname = "Jason Oleham"
media = "M E D I A"
title = "youtube.com/km4ack"
call = "KM4ACK"

#Draw image background
my_image = bytearray(int(296 * 128 / 8))
#my_image = bytearray(int(102 * 128 / 8))
open("yt_logo2.bin", "r").readinto(my_image)
badger.image(my_image)

def badge():
   #includes no image
   #draw rectangle
   badger.pen(0)	#set color to black
   badger.rectangle(0, 0, 296, 40)
   #draw callsign
   badger.font("sans")
   badger.pen(15)	#set color to white
   badger.thickness(3)
   badger.text(media, 55, 20, scale=1.25)
   #draw name
   badger.font("sans")
   badger.pen(0)
   badger.thickness(2)
   badger.text(myname, 8, 52, scale=.85)
   #draw call
   badger.pen(0)
   badger.thickness(4)
   badger.text(call, 6, 85, scale=1.5)
   #draw title
   badger.font("sans")
   badger.thickness(1)
   badger.text(title, 15, 115, scale=.8)
   badger.update()
   
badge()

badger.update()